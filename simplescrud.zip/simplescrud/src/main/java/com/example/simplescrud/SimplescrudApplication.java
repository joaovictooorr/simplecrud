package com.example.simplescrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimplescrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimplescrudApplication.class, args);
	}

}
